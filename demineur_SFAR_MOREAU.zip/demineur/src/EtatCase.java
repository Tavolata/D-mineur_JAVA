
public abstract class EtatCase{
    public abstract void decouvrir(Case c);

    public abstract void marquer(Case c);

}
