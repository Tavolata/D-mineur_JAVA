

public class EtatDecouverte extends EtatCase {

    public EtatDecouverte() {
    }

    public void decouvrir(Case c) 
    {
    }
    
    public void marquer(Case c) 
    {
    }
    
}
